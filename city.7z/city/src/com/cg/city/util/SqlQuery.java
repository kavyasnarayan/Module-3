package com.cg.city.util;

public class SqlQuery {

	public static final String RETRIVE_ALL_QUERY = "select cityname from citylist";
	public static String INSERT_QUERY="insert into register(name,gender,city,phonenumber) values(?,?,?,?)";
}
