package com.cg.city.dto;

import java.io.Serializable;
import java.sql.Connection;

public class CityDto implements Serializable{
	
	
	private static final long serialVersionUID = 1L;
	private String cityId;
	private String cityName;
	private Connection connection;
	
	public Connection getConnection() {
		return connection;
	}
	public void setConnection(Connection connection) {
		this.connection = connection;
	}
	public String getCityId() {
		return cityId;
	}
	public void setCityId(String cityId) {
		this.cityId = cityId;
	}
	public String getCityName() {
		return cityName;
	}
	public void setCityName(String cityName) {
		this.cityName = cityName;
	}
	@Override
	public String toString() {
		return "" + cityName + "";
	}
	
	

}
