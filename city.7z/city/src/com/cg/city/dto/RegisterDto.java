package com.cg.city.dto;

public class RegisterDto {

	private String name;
	private String gender;
	private String city;
	private String phoneNumber;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	@Override
	public String toString() {
		return "RegisterDto [name=" + name + ", gender=" + gender + ", city="
				+ city + ", phoneNumber=" + phoneNumber + "]";
	}
	
	
}
