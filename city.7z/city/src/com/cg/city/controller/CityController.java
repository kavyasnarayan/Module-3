package com.cg.city.controller;

import java.io.IOException;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.city.dto.CityDto;
import com.cg.city.dto.RegisterDto;
import com.cg.city.exception.CityException;
import com.cg.city.service.CityServiceImpl;
import com.cg.city.service.ICityService;

@WebServlet("/CityController")
public class CityController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public CityController() {
		super();
	}

	public void init(ServletConfig config) throws ServletException {
		System.out.println("in init");
	}

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		CityDto cityDto = new CityDto();
		RegisterDto registerDto = new RegisterDto();
		ICityService cityService = new CityServiceImpl();
		String action = request.getParameter("action");
		System.out.println("action is " + action);
		cityDto.setConnection((Connection) request.getAttribute("connection"));
		
		//HttpSession httpSession = request.getSession(false);

		if (action != null && action.equalsIgnoreCase("Login")) {
			List<CityDto> cityList = new ArrayList<CityDto>();
			try {
				cityList = cityService.retriveAllDetails();
				System.out.println("list is" + cityList);
				request.setAttribute("cityList", cityList);
				request.getRequestDispatcher("/view/detail.jsp").forward(
						request, response);
			} catch (CityException e) {
				e.printStackTrace();
			}
		} 

		if (action != null && action.equalsIgnoreCase("Register")) {

			String name = request.getParameter("rname");
			registerDto.setName(name);
			String Gender = request.getParameter("gender");
			registerDto.setGender(Gender);
			String city = request.getParameter("city");
			registerDto.setCity(city);
			String phone = request.getParameter("Pnum");
			registerDto.setPhoneNumber(phone);
			try {
				cityService.addDetails(registerDto);
			} catch (CityException e) {
				e.printStackTrace();
			}
		}

	}
}
