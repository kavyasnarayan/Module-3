package com.cg.city.exception;

public class CityException extends Exception {

	
	private static final long serialVersionUID = 1L;

	public CityException() {
	}

	public CityException(String message) {
		super(message);
	}

}
