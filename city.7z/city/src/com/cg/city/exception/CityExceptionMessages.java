package com.cg.city.exception;

public class CityExceptionMessages {

	public static final String MESSAGE1 = "Data Base Source is missing.Please try later!!!";
	public static final String MESSAGE2 = "Internal Data Base  error ,issing.Please try later!!!";

}
