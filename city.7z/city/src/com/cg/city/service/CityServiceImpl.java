package com.cg.city.service;

import java.util.List;

import com.cg.city.dao.CityDaoImpl;
import com.cg.city.dao.ICityDao;
import com.cg.city.dto.CityDto;
import com.cg.city.dto.RegisterDto;
import com.cg.city.exception.CityException;

public class CityServiceImpl implements ICityService{

	@Override
	public List<CityDto> retriveAllDetails() throws CityException {
	ICityDao cityDao=new CityDaoImpl();
	List<CityDto> cityList=null;
	cityList=cityDao.retriveAllDetails();
	System.out.println(cityList);
		
		return cityList;
	}

	@Override
	public void addDetails(RegisterDto registerDto) throws CityException {
		ICityDao cityDao=new CityDaoImpl();
		cityDao.addDetails(registerDto);
	}
}
