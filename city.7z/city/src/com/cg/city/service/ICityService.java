package com.cg.city.service;

import java.util.List;

import com.cg.city.dto.CityDto;
import com.cg.city.dto.RegisterDto;
import com.cg.city.exception.CityException;

public interface ICityService {
	public List<CityDto> retriveAllDetails() throws CityException;
	public void addDetails(RegisterDto registerDto) throws CityException; 
}
