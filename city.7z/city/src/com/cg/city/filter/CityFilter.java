package com.cg.city.filter;

import java.io.IOException;
import java.sql.Connection;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;

import com.cg.city.exception.CityException;
import com.cg.city.util.DBUtil;

@WebFilter("/CityController")
public class CityFilter implements Filter {

	public CityFilter() {
	}

	public void destroy() {
	}

	public void doFilter(ServletRequest request, ServletResponse response,
			FilterChain chain) throws IOException, ServletException {
		//pre operation
		try {
			connection=DBUtil.getConnection();
			System.out.println(connection);
			request.setAttribute("connection", connection);
		} catch (CityException exception) {
			request.setAttribute("message", exception.getMessage());
		}
		chain.doFilter(request, response);
		//post operation
	}

	public void init(FilterConfig fConfig) throws ServletException {
	}
private Connection connection=null;
}
