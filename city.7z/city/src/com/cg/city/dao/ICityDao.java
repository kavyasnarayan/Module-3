package com.cg.city.dao;

import java.util.List;

import com.cg.city.dto.CityDto;
import com.cg.city.dto.RegisterDto;
import com.cg.city.exception.CityException;

public interface ICityDao {
	public List<CityDto> retriveAllDetails() throws CityException;
	public void addDetails(RegisterDto registerDto) throws CityException;
}
