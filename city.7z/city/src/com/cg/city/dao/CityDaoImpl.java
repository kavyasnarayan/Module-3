package com.cg.city.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.city.dto.CityDto;
import com.cg.city.dto.RegisterDto;
import com.cg.city.exception.CityException;
import com.cg.city.util.DBUtil;
import com.cg.city.util.SqlQuery;

public class CityDaoImpl implements ICityDao {

	@Override
	public List<CityDto> retriveAllDetails() throws CityException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		connection = DBUtil.getConnection();
		int CityCount = 0;
		List<CityDto> cityList = new ArrayList<CityDto>();

		try {

			preparedStatement = connection
					.prepareStatement(SqlQuery.RETRIVE_ALL_QUERY);
			resultSet = preparedStatement.executeQuery();
			System.out.println(resultSet);

			while (resultSet.next()) {
				CityDto cityDto = new CityDto();
				cityDto.setCityName(resultSet.getString(1));
				cityList.add(cityDto);
				CityCount++;
			}
			for (CityDto cityDto : cityList) {
				System.out.println(cityDto.getCityName());
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if (CityCount == 0) {
			return null;
		} else {
			return cityList;
		}

	}

	@Override
	public void addDetails(RegisterDto registerDto) throws CityException {
		int result = 0;
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		connection = DBUtil.getConnection();
		try {
			preparedStatement = connection
					.prepareStatement(SqlQuery.INSERT_QUERY);
			preparedStatement.setString(1, registerDto.getName());
			preparedStatement.setString(2, registerDto.getGender());
			preparedStatement.setString(3, registerDto.getCity());
			preparedStatement.setString(4, registerDto.getPhoneNumber());
			result = preparedStatement.executeUpdate();
			if (result == 1) {
				System.out.println("Successfully inserted");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (connection != null && preparedStatement != null) {
				try {
					preparedStatement.close();
				} catch (SQLException e) {
					throw new CityException("Error in closing db connection");
				}
			}
		}
		if (result == 0) {
			throw new CityException("Insertion Failed");

		}
	}
}
