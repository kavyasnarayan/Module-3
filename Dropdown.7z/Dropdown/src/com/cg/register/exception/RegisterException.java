package com.cg.register.exception;

public class RegisterException extends Exception {

	
	private static final long serialVersionUID = 3946251491649499802L;


	public RegisterException() {
		super();
	}
	

	public RegisterException(String message) {
		super(message);
	}

}
