package com.cg.register.util;

import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import com.cg.register.exception.RegisterException;


public class DBUtil {
	
	private DBUtil(){}

	private static Connection connection;

	public static Connection getConnection() throws RegisterException {
		if(connection==null){
		try {
				InitialContext initalContext = new InitialContext();
				DataSource dataSource = (DataSource) initalContext.lookup("java:/jdbc/OracleDS");
				connection = dataSource.getConnection();
				System.out.println(connection);
			} catch (SQLException exception1) {
				throw new RegisterException();
			} catch (NamingException exception) {
				throw new RegisterException();
			}
		
		}
		return connection;
		
	}

}
