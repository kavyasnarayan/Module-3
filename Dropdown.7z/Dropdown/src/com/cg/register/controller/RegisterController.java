package com.cg.register.controller;

import java.io.IOException;
import java.sql.ResultSet;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.register.bean.CityDTO;
import com.cg.register.bean.DetailsDTO;
import com.cg.register.exception.RegisterException;
import com.cg.register.service.IRegisterService;
import com.cg.register.service.RegisterServiceImpl;
@WebServlet("/RegisterController")
public class RegisterController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       

    public RegisterController() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
			String action = request.getParameter("action");
			HttpSession session = request.getSession(false);
			RequestDispatcher requestDispatcher = null;
			IRegisterService iRegisterService; 
			if (action != null && action.equalsIgnoreCase("form")) {
				session = request.getSession();
				iRegisterService = new RegisterServiceImpl();
				CityDTO cityDTO = new CityDTO();
				try {
					List<CityDTO> cityArray= iRegisterService.getCityNames();
					session.setAttribute("cityArray",cityArray);
					requestDispatcher = getServletContext().getRequestDispatcher("/view/registerfrom.jsp");
					requestDispatcher.forward(request, response);
					
				} catch (RegisterException exception) {
					System.err.println(exception.getMessage());
				}
				
			}

			if (action != null && action.equalsIgnoreCase("Add")) {
				if(session!=null){
					iRegisterService = new RegisterServiceImpl();
					DetailsDTO detailsDTO= new DetailsDTO();
					System.out.println(request.getParameter("username"));
					
					detailsDTO.setCityname(request.getParameter("username"));
					detailsDTO.setPhonenumber(request.getParameter("phoneNumber"));
					detailsDTO.setCityname(request.getParameter("city"));
					detailsDTO.setCourse(request.getParameter("course"));

					try {
						
						int id=iRegisterService.addDetails(detailsDTO);
						System.out.println(id);
					} catch (RegisterException exception) {
						System.err.println(exception.getMessage());
					}
				}
			}
		
	}

}
