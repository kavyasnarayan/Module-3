package com.cg.register.dao;

import java.sql.ResultSet;
import java.util.List;

import com.cg.register.bean.CityDTO;
import com.cg.register.bean.DetailsDTO;
import com.cg.register.exception.RegisterException;

public interface IRegisterDao {

	List<CityDTO> getCityNames() throws RegisterException;

	int addDetails(DetailsDTO detailsDTO) throws RegisterException;

}
