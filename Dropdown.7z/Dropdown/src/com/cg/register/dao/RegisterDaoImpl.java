package com.cg.register.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.register.bean.CityDTO;
import com.cg.register.bean.DetailsDTO;
import com.cg.register.exception.RegisterException;
import com.cg.register.util.DBUtil;

public class RegisterDaoImpl implements IRegisterDao {
	Connection connection;
	PreparedStatement preparedStatement;
	ResultSet resultSet = null;
	@Override
	public List<CityDTO> getCityNames() throws RegisterException {
		List<CityDTO> cityArray = new ArrayList<>();
		
		
		try {
			 connection = DBUtil.getConnection();
			preparedStatement = connection.prepareStatement("SELECT cityname from city");
			resultSet= preparedStatement.executeQuery();
			
			while (resultSet.next()) {
				CityDTO cityDTO= new CityDTO();
				cityDTO.setCity(resultSet.getString(1));
				cityArray.add(cityDTO);
			}
			
		} catch (RegisterException e) {
			throw new RegisterException("DB connection");
		} catch (SQLException e) {
			throw new RegisterException("unable to fetch cities data");
		}
		
		return cityArray;

	}

	@Override
	public int addDetails(DetailsDTO detailsDTO) throws RegisterException {
		int id=-1;
		
		
		try {
			connection = DBUtil.getConnection();
			preparedStatement = connection.prepareStatement("INSERT INTO registeration values(?,?,?,?)");
			System.out.println(detailsDTO.getName());
			preparedStatement.setString(1, detailsDTO.getName());
			preparedStatement.setString(2, detailsDTO.getPhonenumber());
			preparedStatement.setString(3, detailsDTO.getCityname());
			preparedStatement.setString(4, detailsDTO.getCourse());
			id= preparedStatement.executeUpdate();
			System.out.println(id);
			
		} catch (SQLException exception) {
			throw new RegisterException(exception.getMessage());
		} catch (RegisterException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return id;
	}

}
