package com.cg.register.service;

import java.util.List;

import com.cg.register.bean.CityDTO;
import com.cg.register.bean.DetailsDTO;
import com.cg.register.dao.IRegisterDao;
import com.cg.register.dao.RegisterDaoImpl;
import com.cg.register.exception.RegisterException;

public class RegisterServiceImpl implements IRegisterService {

	IRegisterDao iRegisterDao;
	
	@Override
	public List<CityDTO> getCityNames() throws RegisterException {
		iRegisterDao= new RegisterDaoImpl(); 
		List<CityDTO> cityArray = null;
		cityArray=iRegisterDao.getCityNames();

		return cityArray;
	}

	@Override
	public int addDetails(DetailsDTO detailsDTO) throws RegisterException {
		iRegisterDao= new RegisterDaoImpl(); 
		int id=iRegisterDao.addDetails(detailsDTO);
		return id;
	}

}
