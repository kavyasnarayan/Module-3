package com.cg.zipcode.service;

import java.util.List;

import com.cg.zipcode.bean.CandidateDTO;
import com.cg.zipcode.bean.ZipcodeDTO;
import com.cg.zipcode.dao.IZipcodeDAO;
import com.cg.zipcode.dao.ZipcodeDaoImpl;
import com.cg.zipcode.exception.ZipcodeException;

public class ZipcodeServiceImpl implements IZipcodeService {

	@Override
	public List<ZipcodeDTO> retriveAllDetails() throws ZipcodeException {
		IZipcodeDAO zipcodeDAO=new ZipcodeDaoImpl();
		List<ZipcodeDTO> zipcodeList=null;
		zipcodeList=zipcodeDAO.retriveAllDetails();
		
		return zipcodeList;
		
	}

	@Override
	public void addDetails(CandidateDTO candidateDTO) throws ZipcodeException {
		IZipcodeDAO zipcodeDAO=new ZipcodeDaoImpl();
		zipcodeDAO.addDetails(candidateDTO);
	}
	

}
