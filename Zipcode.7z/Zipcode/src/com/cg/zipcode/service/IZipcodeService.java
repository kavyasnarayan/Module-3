package com.cg.zipcode.service;

import java.util.List;

import com.cg.zipcode.bean.CandidateDTO;
import com.cg.zipcode.bean.ZipcodeDTO;
import com.cg.zipcode.exception.ZipcodeException;



public interface IZipcodeService {
	
	public List<ZipcodeDTO> retriveAllDetails() throws ZipcodeException;

	public void addDetails(CandidateDTO candidateDTO) throws ZipcodeException;

}
