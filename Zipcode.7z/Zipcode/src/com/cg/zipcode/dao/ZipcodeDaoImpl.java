package com.cg.zipcode.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.zipcode.bean.CandidateDTO;
import com.cg.zipcode.bean.ZipcodeDTO;
import com.cg.zipcode.exception.ZipcodeException;
import com.cg.zipcode.util.DbUtil;
import com.cg.zipcode.util.SQLQuerry;

public class ZipcodeDaoImpl implements IZipcodeDAO {

	@Override
	public List<ZipcodeDTO> retriveAllDetails() throws ZipcodeException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		ZipcodeDTO zipcodeDTO = new ZipcodeDTO();
		List<ZipcodeDTO> zipcodeList = new ArrayList<ZipcodeDTO>();
		connection = DbUtil.getConnection();
		int zipcodeCount = 0;

		try {
			preparedStatement = connection
					.prepareStatement(SQLQuerry.RETRIVE_ALL_QUERY);
			resultSet = preparedStatement.executeQuery();

			while (resultSet.next()) {
				zipcodeDTO = new ZipcodeDTO();
				zipcodeDTO.setZipcode(resultSet.getString(1));
				zipcodeList.add(zipcodeDTO);
				zipcodeCount++;
			}
		} catch (SQLException e) {
			throw new ZipcodeException("Error in adding cities"
					+ e.getMessage());
		}
		if (zipcodeCount == 0) {
			System.out.println("No zipcode to display");
		}

		return zipcodeList;
	}

	@Override
	public void addDetails(CandidateDTO candidateDTO) throws ZipcodeException {

		Connection connection = null;
		connection = DbUtil.getConnection();
		PreparedStatement preparedStatement = null;
		PreparedStatement preparedStatement1 = null;
		ResultSet resultSet = null;
		String cityname = null;
		int result = 0;

		try {
			
			preparedStatement1 = connection
					.prepareStatement(SQLQuerry.SELECT_CITY_QUERY);
			preparedStatement1.setString(1, candidateDTO.getZipcode());
			resultSet = preparedStatement1.executeQuery();
			if (resultSet.next()) {
				cityname = resultSet.getString(1);
				System.out.println("city name is" + cityname);
			}
			System.out.println(candidateDTO.getPhonenumber());
			preparedStatement = connection
					.prepareStatement(SQLQuerry.INSERT_QUERY);
			preparedStatement.setString(1, candidateDTO.getFirstname());
			preparedStatement.setString(2, candidateDTO.getLastname());
			preparedStatement.setString(3, candidateDTO.getPhonenumber());
			preparedStatement.setString(4, candidateDTO.getAddress());
			preparedStatement.setString(5, cityname);
			preparedStatement.setString(6, candidateDTO.getCourse());
			result = preparedStatement.executeUpdate();

			if (result == 1) {
				System.out.println("Successful");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {

			try {
				preparedStatement.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

	}
}