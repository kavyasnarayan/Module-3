package com.cg.zipcode.exception;

public class ZipcodeExceptionMessages {

	public static final String MESSAGE1="DataBase source is missing.Please try later!!!" ;
	public static final String MESSAGE2="Internal DataBase source is missing.Please try later!!!" ;

}
