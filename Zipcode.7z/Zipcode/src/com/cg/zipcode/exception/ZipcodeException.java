package com.cg.zipcode.exception;

public class ZipcodeException extends Exception {
	private static final long serialVersionUID = 1L;

	public ZipcodeException() {
	}

	public ZipcodeException(String message) {
		super(message);

}
}
