package com.cg.zipcode.filter;

import java.io.IOException;
import java.sql.Connection;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;



import com.cg.zipcode.exception.ZipcodeException;
import com.cg.zipcode.util.DbUtil;


@WebFilter("/ZipcodeController")
public class Zipcodefilter implements Filter {

    public Zipcodefilter() {
    }

	
	public void destroy() {
	}

	
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		try {
			connection=DbUtil.getConnection();
			request.setAttribute("connection", connection);
		} catch (ZipcodeException exception) {
			request.setAttribute("message", exception.getMessage());
			request.getRequestDispatcher("/ErrorPage").forward(request, response);
		}
		chain.doFilter(request, response);
	}
	
	
	public void init(FilterConfig fConfig) throws ServletException {
	}
	private Connection connection=null;
}
