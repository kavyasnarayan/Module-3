package com.cg.zipcode.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;






import com.cg.zipcode.bean.CandidateDTO;
import com.cg.zipcode.bean.ZipcodeDTO;
import com.cg.zipcode.exception.ZipcodeException;
import com.cg.zipcode.service.IZipcodeService;
import com.cg.zipcode.service.ZipcodeServiceImpl;


@WebServlet("/ZipcodeController")
public class ZipcodeController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public ZipcodeController() {
        super();
    }

	
	public void init(ServletConfig config) throws ServletException {
		System.out.println("init");
	}


	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		ZipcodeDTO zipcodeDTO=new ZipcodeDTO();
		CandidateDTO candidateDTO=new CandidateDTO();
		IZipcodeService zipcodeService=new ZipcodeServiceImpl();
		
		String action=request.getParameter("action");
		System.out.println("action is"+action);
		HttpSession httpSession=request.getSession(false);

		
		if (action != null && action.equalsIgnoreCase("Click")){
			System.out.println("inside if");
			
			try {
				List<ZipcodeDTO> zipcodeList=new ArrayList<ZipcodeDTO>();
				zipcodeList = zipcodeService.retriveAllDetails();
				System.out.println("list" +zipcodeList);
				request.setAttribute("zipcodeList",zipcodeList );
				request.getRequestDispatcher("/view/RegistrationPage.jsp").forward(request, response);
			} catch (ZipcodeException e) {
				System.out.println("Error in adding cities controller1"+e.getMessage());
			}
		}
			if (action != null && action.equalsIgnoreCase("Register")){
				System.out.println("Register");
				
			String firstname=request.getParameter("firstname");
			candidateDTO.setFirstname(firstname);
			
			String lastname=request.getParameter("lastname");
			candidateDTO.setFirstname(lastname);
			
			String phonenumber=request.getParameter("phonenumber");
			System.out.println(phonenumber);
			candidateDTO.setPhonenumber(phonenumber);
			
			String address=request.getParameter("address");
			candidateDTO.setAddress(address);
			
			String city=request.getParameter("city");
			candidateDTO.setCity(city);
			
			String course=request.getParameter("course");
			candidateDTO.setCourse(course);
			
			String zip=request.getParameter("zipcode");
			candidateDTO.setZipcode(zip);
			
			try {		
				zipcodeService.addDetails(candidateDTO);
				request.setAttribute("dto",candidateDTO );
				request.getRequestDispatcher("/view/display.jsp").forward(
						request, response); 
			} catch (ZipcodeException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			}	
	}
	}

