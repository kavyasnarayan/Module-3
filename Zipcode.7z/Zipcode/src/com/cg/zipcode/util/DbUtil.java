package com.cg.zipcode.util;

import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import com.cg.zipcode.exception.ZipcodeException;
import com.cg.zipcode.exception.ZipcodeExceptionMessages;



public class DbUtil {
	private DbUtil(){
		
	}
	private static Connection connection;
	public static Connection getConnection() throws ZipcodeException {
		if(connection==null){
			try {
				InitialContext initialContext=new InitialContext();
				DataSource dataSource=(DataSource) initialContext.lookup("java:/jdbc/OracleDS");
				connection=dataSource.getConnection();
			} catch (NamingException e) {
				throw new ZipcodeException(ZipcodeExceptionMessages.MESSAGE1);
			}
			catch ( SQLException e) {
				throw new ZipcodeException(ZipcodeExceptionMessages.MESSAGE2);
			}
			
			
		}
		return connection;
}
}
