package com.cg.zipcode.util;

public class SQLQuerry {

	public static final String RETRIVE_ALL_QUERY = "SELECT zip  FROM zipcode";
	public static final String INSERT_QUERY = "INSERT INTO candidate(firstname,lastname,phonenumber,address,city,course) VALUES (?,?,?,?,?,?)";
	public static final String SELECT_CITY_QUERY = "SELECT city from zipcode WHERE zip=?";
}
