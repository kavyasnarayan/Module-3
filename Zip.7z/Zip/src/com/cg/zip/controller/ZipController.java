package com.cg.zip.controller;

import java.io.IOException;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.zip.dto.DetailsDto;
import com.cg.zip.dto.ZipDto;
import com.cg.zip.exception.ZipException;
import com.cg.zip.service.IZipService;
import com.cg.zip.service.ZipServiceImpl;

@WebServlet("/ZipController")
public class ZipController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public ZipController() {
		super();
	}

	public void init(ServletConfig config) throws ServletException {
		System.out.println("in init");
	}



	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		System.out.println("in post");
		ZipDto zipDto = new ZipDto();
		DetailsDto detailsDto = new DetailsDto();
		IZipService service=new ZipServiceImpl();
		String action = request.getParameter("action");
		System.out.println("action is " + action);
		zipDto .setConnection((Connection) request.getAttribute("connection"));

		if (action != null && action.equalsIgnoreCase("Click")) {
			List<ZipDto> list=new ArrayList<ZipDto>();
			try {
				list=service.retriveZipCode();
				request.setAttribute("list", list);
			} catch (ZipException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			request.getRequestDispatcher("/view/addDetail.jsp").forward(
					request, response);
		} 

		if (action != null && action.equalsIgnoreCase("AddDetails")) {
			
		String first=request.getParameter("fname");
		detailsDto.setFirstname(first);
		String last=request.getParameter("lname");
		detailsDto.setLastName(last);
		String pnumber=request.getParameter("phonename");
		detailsDto.setPhoneNumber(pnumber);
		String add=request.getParameter("address");
		detailsDto.setAddress(add);
		String code=request.getParameter("code");
		detailsDto.setZipCode(code);

				System.out.println("on add details");
				
				try {
					service.addDetails(detailsDto);
					request.setAttribute("dto",detailsDto );
					request.getRequestDispatcher("/view/display.jsp").forward(
							request, response);
				} catch (ZipException e) {
					e.printStackTrace();
				}
		}

	}
}
