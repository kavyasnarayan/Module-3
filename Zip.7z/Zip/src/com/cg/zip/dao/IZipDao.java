package com.cg.zip.dao;

import java.util.List;

import com.cg.zip.dto.DetailsDto;
import com.cg.zip.dto.ZipDto;
import com.cg.zip.exception.ZipException;

public interface IZipDao {
	public List<ZipDto> retriveZipCode() throws ZipException;
	public void addDetails( DetailsDto detailsDto) throws ZipException;
}
