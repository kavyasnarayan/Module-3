package com.cg.zip.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.zip.dto.DetailsDto;
import com.cg.zip.dto.ZipDto;
import com.cg.zip.exception.ZipException;
import com.cg.zip.util.DBUtil;
import com.cg.zip.util.SqlQuery;

public class ZipDao implements IZipDao {

	@Override
	public List<ZipDto> retriveZipCode() throws ZipException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		int zipCount = 0;
		connection = DBUtil.getConnection();
		List<ZipDto> list = new ArrayList<ZipDto>();
		try {
			preparedStatement = connection
					.prepareStatement(SqlQuery.RETRIVE_ALL_QUERY);
			resultSet = preparedStatement.executeQuery();

			while (resultSet.next()) {
				ZipDto zipDto = new ZipDto();
				zipDto.setZipCode(resultSet.getString(1));
				
				list.add(zipDto);
				zipCount++;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if (zipCount == 0) {
			System.out.println("No zipcode found");
		}
		return list;
	}

	@Override
	public void addDetails(DetailsDto detailsDto) throws ZipException {
		int result = 0;
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		PreparedStatement preparedStatement1 = null;
		ResultSet resultSet=null;
		String cname = null;
		
		connection = DBUtil.getConnection();
		try {
		
			preparedStatement1=connection.prepareStatement(SqlQuery.SELECT_CITY_QUERY);
			preparedStatement1.setString(1, detailsDto.getZipCode());
			resultSet=preparedStatement1.executeQuery();
			if(resultSet.next()){
			cname=resultSet.getString(1);
			System.out.println( "city name is"+cname);
			}
			
			preparedStatement = connection.prepareStatement(SqlQuery.INSERT_ALL_QUERY);
			preparedStatement.setString(1, detailsDto.getFirstname());
			preparedStatement.setString(2, detailsDto.getLastName());
			preparedStatement.setString(3, detailsDto.getPhoneNumber());
			preparedStatement.setString(4, detailsDto.getAddress());
			preparedStatement.setString(5, cname);
			result = preparedStatement.executeUpdate();
			if (result == 1) {
				System.out.println("successfully inserted");
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			if (connection != null && preparedStatement != null && resultSet!=null ) {
				try {
					resultSet.close();
					preparedStatement.close();
				} catch (SQLException e) {
					throw new ZipException("Error in closing db connection");
				}
			}
		}
		if (result == 0) {
			throw new ZipException("Insertion Failed");
		}

	}
}
