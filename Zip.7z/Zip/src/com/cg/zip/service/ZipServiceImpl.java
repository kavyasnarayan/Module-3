package com.cg.zip.service;

import java.util.List;

import com.cg.zip.dao.IZipDao;
import com.cg.zip.dao.ZipDao;
import com.cg.zip.dto.DetailsDto;
import com.cg.zip.dto.ZipDto;
import com.cg.zip.exception.ZipException;

public class ZipServiceImpl implements IZipService {

	@Override
	public List<ZipDto> retriveZipCode() throws ZipException {
		IZipDao dao=new ZipDao();
		List<ZipDto> list=null;
		list=dao.retriveZipCode();
		
		return list;
	}

	@Override
	public void addDetails(DetailsDto detailsDto) throws ZipException {
		IZipDao dao=new ZipDao();	
		dao.addDetails(detailsDto);
	}

}
