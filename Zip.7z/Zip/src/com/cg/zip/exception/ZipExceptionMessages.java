package com.cg.zip.exception;

public class ZipExceptionMessages {
	public static final String MESSAGE1 = "Data Base Source is missing.Please try later!!!";
	public static final String MESSAGE2 = "Internal Data Base  error ,issing.Please try later!!!";
}
