package com.cg.zip.exception;

public class ZipException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ZipException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ZipException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	
}
