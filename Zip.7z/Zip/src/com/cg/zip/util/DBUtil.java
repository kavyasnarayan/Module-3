package com.cg.zip.util;

import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;



import com.cg.zip.exception.ZipException;
import com.cg.zip.exception.ZipExceptionMessages;

public class DBUtil {
	private DBUtil() {
	}
	private static Connection connection;
	public static Connection getConnection() throws ZipException{
		if (connection == null) {
			try {
				InitialContext initialContext = new InitialContext();
				DataSource dataSource = (DataSource) initialContext
						.lookup("java:/jdbc/OracleDS");
				connection = dataSource.getConnection();
				System.out.println("connected to db"+connection);
			
			} catch (NamingException e) {
				throw new  ZipException(ZipExceptionMessages.MESSAGE1);
			} catch (SQLException e) {
				throw new ZipException(ZipExceptionMessages.MESSAGE2);
			}
		}
		return connection;
		
}
}
