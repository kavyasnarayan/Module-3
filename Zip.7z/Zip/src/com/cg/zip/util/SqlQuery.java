package com.cg.zip.util;

public class SqlQuery {

	public static final String RETRIVE_ALL_QUERY = "select zipcode from zip";
	public static final String INSERT_ALL_QUERY="insert into details(firstname,lastname,phonenumber,address,city) values(?,?,?,?,?)";
	
	public static final String SELECT_CITY_QUERY="select city from zip where zipcode=?";
	
	public static final String SELECT_detail_QUERY="select city,state,country from zip where zipcode=?";
	
}
